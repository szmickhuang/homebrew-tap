package agent

import (
	"context"
	"encoding/json"
	"errors"
	"slices"
	"testing"

	"charm.land/fantasy"
	"github.com/charmbracelet/crush/internal/message"
	"github.com/stretchr/testify/require"
)

// A turn stopped at its output token limit finishes with FinishReasonLength,
// so nothing on the error path settles the call it left unfinished.
func TestSettleTurn(t *testing.T) {
	t.Parallel()

	env := testEnv(t)
	agent := &sessionAgent{messages: env.messages}

	sess, err := env.sessions.Create(t.Context(), "t")
	require.NoError(t, err)

	assistant, err := env.messages.Create(t.Context(), sess.ID, message.CreateMessageParams{
		Role:  message.Assistant,
		Parts: []message.ContentPart{},
	})
	require.NoError(t, err)

	// One call that landed normally, one cut off mid arguments.
	assistant.AddToolCall(message.ToolCall{ID: "done", Name: "view", Input: `{"file_path":"a"}`, Finished: true})
	assistant.AddToolCall(message.ToolCall{ID: "cutoff", Name: "write", Finished: false})
	assistant.AddFinish(message.FinishReasonMaxTokens, "", "")
	require.NoError(t, env.messages.Update(t.Context(), assistant))

	require.NoError(t, agent.settleTurn(t.Context(), &assistant, answeredOnly("done"), nil))

	calls := assistant.ToolCalls()
	require.Len(t, calls, 2)
	for _, tc := range calls {
		require.True(t, tc.Finished, "%s should be finished", tc.ID)
	}

	// Whatever the model managed to write stays in the transcript; the send
	// path is where it becomes something a provider will accept.
	for _, part := range assistant.ToAIMessage()[0].Content {
		if tc, ok := fantasy.AsMessagePart[fantasy.ToolCallPart](part); ok {
			require.True(t, json.Valid([]byte(tc.Input)), "%s should reach the provider parseable", tc.ToolCallID)
		}
	}

	// Without a result the next request carries a tool call with no reply,
	// which providers reject.
	msgs, err := env.messages.List(t.Context(), sess.ID)
	require.NoError(t, err)
	var results []message.ToolResult
	for _, m := range msgs {
		if m.Role == message.Tool {
			results = append(results, m.ToolResults()...)
		}
	}
	require.Len(t, results, 1)
	require.Equal(t, "cutoff", results[0].ToolCallID)
	require.True(t, results[0].IsError)
	require.Equal(t, truncatedToolCallResult, results[0].Content)
}

// A safety classifier can stop a response mid tool call too. Reporting that
// as an output limit sends the next attempt after the wrong fix.
func TestSettleTurnReportsRefusal(t *testing.T) {
	t.Parallel()

	env := testEnv(t)
	agent := &sessionAgent{messages: env.messages}

	sess, err := env.sessions.Create(t.Context(), "t")
	require.NoError(t, err)

	assistant, err := env.messages.Create(t.Context(), sess.ID, message.CreateMessageParams{
		Role:  message.Assistant,
		Parts: []message.ContentPart{},
	})
	require.NoError(t, err)
	assistant.AddToolCall(message.ToolCall{ID: "cutoff", Name: "bash", Finished: false})
	assistant.AddFinish(message.FinishReasonContentFilter, "", "")
	require.NoError(t, env.messages.Update(t.Context(), assistant))

	require.NoError(t, agent.settleTurn(t.Context(), &assistant, answeredOnly("done"), nil))

	msgs, err := env.messages.List(t.Context(), sess.ID)
	require.NoError(t, err)
	var results []message.ToolResult
	for _, m := range msgs {
		if m.Role == message.Tool {
			results = append(results, m.ToolResults()...)
		}
	}
	require.Len(t, results, 1)
	require.True(t, results[0].IsError)
	require.Equal(t, refusedToolCallResult, results[0].Content)
}

// Completed turns must be left alone, and must not gain tool result messages.
func TestSettleTurnLeavesCompleteTurnsAlone(t *testing.T) {
	t.Parallel()

	env := testEnv(t)
	agent := &sessionAgent{messages: env.messages}

	sess, err := env.sessions.Create(t.Context(), "t")
	require.NoError(t, err)

	assistant, err := env.messages.Create(t.Context(), sess.ID, message.CreateMessageParams{
		Role:  message.Assistant,
		Parts: []message.ContentPart{},
	})
	require.NoError(t, err)
	assistant.AddToolCall(message.ToolCall{ID: "done", Name: "view", Input: `{}`, Finished: true})
	assistant.AddFinish(message.FinishReasonToolUse, "", "")
	require.NoError(t, env.messages.Update(t.Context(), assistant))

	require.NoError(t, agent.settleTurn(t.Context(), &assistant, answeredOnly("done"), nil))

	msgs, err := env.messages.List(t.Context(), sess.ID)
	require.NoError(t, err)
	for _, m := range msgs {
		require.NotEqual(t, message.Tool, m.Role, "no tool result should be invented")
	}
}

// answeredOnly reports a reply for exactly the given tool call IDs.
func answeredOnly(ids ...string) func(string) bool {
	return func(id string) bool { return slices.Contains(ids, id) }
}

// A failed or canceled turn settles every call still waiting, finished or
// not, and says which of the two happened.
func TestSettleTurnOnRunError(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		err  error
		want string
	}{
		"canceled": {context.Canceled, canceledToolCallResult},
		"failed":   {errors.New("boom"), failedToolCallResult},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			env := testEnv(t)
			agent := &sessionAgent{messages: env.messages}

			sess, err := env.sessions.Create(t.Context(), "t")
			require.NoError(t, err)
			assistant, err := env.messages.Create(t.Context(), sess.ID, message.CreateMessageParams{
				Role: message.Assistant,
				Parts: []message.ContentPart{
					message.ToolCall{ID: "done", Name: "view", Input: `{}`, Finished: true},
					message.ToolCall{ID: "running", Name: "bash", Input: `{}`, Finished: true},
					message.ToolCall{ID: "cutoff", Name: "write", Finished: false},
				},
			})
			require.NoError(t, err)

			require.NoError(t, agent.settleTurn(t.Context(), &assistant, answeredOnly("done"), tc.err))

			msgs, err := env.messages.List(t.Context(), sess.ID)
			require.NoError(t, err)
			replies := map[string]string{}
			for _, m := range msgs {
				for _, tr := range m.ToolResults() {
					replies[tr.ToolCallID] = tr.Content
				}
			}
			require.Equal(t, map[string]string{"running": tc.want, "cutoff": tc.want}, replies)
		})
	}
}

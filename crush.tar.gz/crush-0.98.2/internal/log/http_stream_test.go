package log

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

// Draining the body to log it waits for the stream to end, which turns every
// stream into one blocking read.
func TestHTTPLoggerDoesNotBufferStreamingResponses(t *testing.T) {
	t.Parallel()

	slog.SetLogLoggerLevel(slog.LevelDebug)

	release := make(chan struct{})
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(http.StatusOK)
		fmt.Fprint(w, "event: ping\ndata: {}\n\n")
		w.(http.Flusher).Flush()
		// Hold the response open, the way a provider does mid-turn.
		<-release
	}))
	defer srv.Close()
	defer close(release)

	client := NewHTTPClient()
	ctx, cancel := context.WithTimeout(t.Context(), 5*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, srv.URL, nil)
	require.NoError(t, err)

	resp, err := client.Do(req)
	require.NoError(t, err)
	defer resp.Body.Close()

	// Read through a local rather than resp.Body directly. The body is read
	// from a goroutine, and bodyclose loses track of a response that escapes
	// into a closure, so it reports the body as never closed even though the
	// defer above closes it.
	body := resp.Body
	first := make(chan string, 1)
	go func() {
		buf := make([]byte, 64)
		n, _ := body.Read(buf)
		first <- string(buf[:n])
	}()

	select {
	case got := <-first:
		require.Contains(t, got, "ping", "the first event should arrive before the response ends")
	case <-time.After(2 * time.Second):
		t.Fatal("the first streamed event never arrived: the logger buffered the whole body")
	}
}

// The tail is what matters when diagnosing a stall, so the head is dropped.
func TestRecordingBodyKeepsTail(t *testing.T) {
	t.Parallel()

	var body string
	var truncated bool
	r := &recordingBody{
		inner: io.NopCloser(io.LimitReader(repeatReader{'a'}, maxRecordedBodyBytes+1024)),
		log:   func(b string, tr bool) { body, truncated = b, tr },
	}
	_, err := io.Copy(io.Discard, r)
	require.NoError(t, err)
	require.NoError(t, r.Close())

	require.True(t, truncated, "an over-long body should report truncation")
	require.Len(t, body, maxRecordedBodyBytes)
}

// A stream many times the cap is trimmed as it goes, so what is held stays
// bounded without recopying the tail on every read.
func TestRecordingBodyTrimsLongStreams(t *testing.T) {
	t.Parallel()

	var body string
	var truncated bool
	r := &recordingBody{
		inner: io.NopCloser(io.LimitReader(repeatReader{'a'}, 5*maxRecordedBodyBytes)),
		log:   func(b string, tr bool) { body, truncated = b, tr },
	}
	_, err := io.Copy(io.Discard, r)
	require.NoError(t, err)
	require.NoError(t, r.Close())

	require.True(t, truncated)
	require.Len(t, body, maxRecordedBodyBytes, "only the tail is kept, however long the stream")
}

// Closing early (a cancelled turn) must still produce exactly one log line.
func TestRecordingBodyLogsOnceOnEarlyClose(t *testing.T) {
	t.Parallel()

	var calls int
	r := &recordingBody{
		inner: io.NopCloser(io.LimitReader(repeatReader{'x'}, 1<<20)),
		log:   func(string, bool) { calls++ },
	}
	buf := make([]byte, 16)
	_, err := r.Read(buf)
	require.NoError(t, err)
	require.NoError(t, r.Close())
	require.NoError(t, r.Close())
	require.Equal(t, 1, calls)
}

type repeatReader struct{ b byte }

func (r repeatReader) Read(p []byte) (int, error) {
	for i := range p {
		p[i] = r.b
	}
	return len(p), nil
}

// A body can be closed from one goroutine while another is blocked in Read;
// that is how a stream gets aborted mid-turn.
func TestRecordingBodyCloseDuringRead(t *testing.T) {
	t.Parallel()

	var calls int
	r := &recordingBody{
		inner: io.NopCloser(io.LimitReader(repeatReader{'x'}, 1<<24)),
		log:   func(string, bool) { calls++ },
	}

	done := make(chan struct{})
	go func() {
		defer close(done)
		buf := make([]byte, 512)
		for range 20000 {
			if _, err := r.Read(buf); err != nil {
				return
			}
		}
	}()

	time.Sleep(time.Millisecond)
	require.NoError(t, r.Close())
	<-done
	require.Equal(t, 1, calls, "an aborted stream still logs exactly once")
}

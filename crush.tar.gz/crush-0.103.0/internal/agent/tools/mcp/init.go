// Package mcp provides functionality for managing Model Context Protocol (MCP)
// clients within the Crush application.
package mcp

import (
	"context"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"os/exec"
	"slices"
	"strings"
	"sync"
	"time"

	"github.com/charmbracelet/crush/internal/config"
	"github.com/charmbracelet/crush/internal/csync"
	"github.com/charmbracelet/crush/internal/home"
	"github.com/charmbracelet/crush/internal/oauth"
	mcpoauth "github.com/charmbracelet/crush/internal/oauth/mcp"
	"github.com/charmbracelet/crush/internal/permission"
	"github.com/charmbracelet/crush/internal/pubsub"
	"github.com/charmbracelet/crush/internal/version"
	"github.com/modelcontextprotocol/go-sdk/auth"
	"github.com/modelcontextprotocol/go-sdk/jsonrpc"
	"github.com/modelcontextprotocol/go-sdk/mcp"
	"golang.org/x/oauth2"
)

// parseLevel converts an MCP logging level string to a slog.Level. The
// entire MCP logging feature is deprecated per SEP-2577 but remains
// functional; servers may still send log notifications during the
// deprecation window.
func parseLevel(level string) slog.Level {
	switch level {
	case "info":
		return slog.LevelInfo
	case "notice":
		return slog.LevelInfo
	case "warning":
		return slog.LevelWarn
	default:
		return slog.LevelDebug
	}
}

// ClientSession wraps an mcp.ClientSession with a context cancel function so
// that the context created during session establishment is properly cleaned up
// on close.
type ClientSession struct {
	*mcp.ClientSession
	cancel       context.CancelFunc
	oauthHandler *mcpoauth.Handler
	// channel reports whether this server is an active channel (it declared
	// the claude/channel capability and was opted in via --channels or
	// channel_enabled in config).
	channel bool
	// channelCapable reports whether the server declared the claude/channel
	// capability, whether or not it was opted in.
	channelCapable bool
}

// Close cancels the session context and then closes the underlying session.
func (s *ClientSession) Close() error {
	s.cancel()
	if s.oauthHandler != nil {
		s.oauthHandler.Close()
	}
	return s.ClientSession.Close()
}

var (
	sessions = csync.NewMap[string, *ClientSession]()
	states   = csync.NewMap[string, ClientInfo]()
	authURLs = csync.NewMap[string, *mcpoauth.Handler]()
	broker   = pubsub.NewBroker[Event]()
	initOnce sync.Once
	initDone = make(chan struct{})

	// initStarted records whether Initialize has been armed. WaitForInit only
	// blocks once initialization is expected; coordinators built outside app
	// startup never arm it and so must not wait forever. initArmedAt anchors
	// WaitForInitBudget's deadline: the budget is measured from arming, not
	// from each call, so sequential waiters share one deadline instead of
	// stacking fresh budgets.
	initMu      sync.Mutex
	initStarted bool
	initArmedAt time.Time

	// refs counts the apps sharing the process-global MCP clients (see
	// Acquire). A server hosts one app per workspace, so only the Close
	// that releases the last reference may close the sessions.
	refsMu sync.Mutex
	refs   int

	// renewMus serializes lazy session renewals per server so concurrent tool
	// calls cannot race to rebuild the same session.
	renewMusMu sync.Mutex
	renewMus   = map[string]*sync.Mutex{}

	// gens hands out a per-server generation number. teardown bumps a
	// server's generation; an init goroutine captures it at launch and only
	// commits its session if the generation is still current. A config
	// change that restarts a server mid-connect thus invalidates the
	// in-flight attempt instead of letting it register a stale session.
	gens = csync.NewMap[string, uint64]()

	// suppressMus serializes browser-suppression per server so only one
	// remote (server-driven) OAuth flow is active for a server at a time.
	suppressMus = csync.NewMap[string, *sync.Mutex]()

	// newSession creates a client session. It is a seam so tests can exercise
	// renewal concurrency without spawning a real transport.
	newSession = createSession
)

// suppressBrowserKey marks a context as requesting the OAuth handler not
// open a local browser; the caller surfaces the authorization URL itself.
type suppressBrowserKey struct{}

// ArmInit marks that MCP initialization is expected so WaitForInit blocks
// until it completes. Call this synchronously before launching Initialize in a
// goroutine; otherwise WaitForInit could observe the not-yet-started state and
// return early, letting the tool list be read before MCP tools register.
func ArmInit() {
	initMu.Lock()
	initStarted = true
	initArmedAt = time.Now()
	initMu.Unlock()
}

// DisarmInit undoes ArmInit so WaitForInit stops blocking and returns
// immediately. It exists for tests in other packages that arm the gate
// without ever running Initialize and must not leak a permanently-blocking
// gate into the rest of the test binary. Production code never needs it.
func DisarmInit() {
	initMu.Lock()
	initStarted = false
	initMu.Unlock()
}

// renewLock returns the per-server mutex used to serialize session renewals,
// creating it on first use.
func renewLock(name string) *sync.Mutex {
	renewMusMu.Lock()
	defer renewMusMu.Unlock()
	mu, ok := renewMus[name]
	if !ok {
		mu = &sync.Mutex{}
		renewMus[name] = mu
	}
	return mu
}

// State represents the current state of an MCP client
type State int

const (
	StateDisabled State = iota
	StateStarting
	StateConnected
	StateError
	StateNeedsAuth
)

func (s State) String() string {
	switch s {
	case StateDisabled:
		return "disabled"
	case StateStarting:
		return "starting"
	case StateConnected:
		return "connected"
	case StateError:
		return "error"
	case StateNeedsAuth:
		return "needs auth"
	default:
		return "unknown"
	}
}

// EventType represents the type of MCP event
type EventType uint

const (
	EventStateChanged EventType = iota
	EventToolsListChanged
	EventPromptsListChanged
	EventResourcesListChanged
	// EventChannelMessage is published when a channel server pushes a
	// notifications/claude/channel event. ChannelMessage carries the rendered,
	// escaped <channel> element ready for injection into the session.
	EventChannelMessage
)

// Event represents an event in the MCP system
type Event struct {
	Type   EventType
	Name   string
	State  State
	Error  error
	Counts Counts
	// ChannelMessage is set only for EventChannelMessage: the fully rendered
	// and escaped <channel>...</channel> element to inject into the session.
	ChannelMessage string
}

// Counts number of available tools, prompts, etc.
type Counts struct {
	Tools     int
	Prompts   int
	Resources int
}

// ClientInfo holds information about an MCP client's state.
type ClientInfo struct {
	Name        string
	State       State
	Error       error
	Client      *ClientSession
	Counts      Counts
	ConnectedAt time.Time

	// Config is the configuration the server last successfully connected
	// with. Reconcile compares it against the live config to decide whether
	// a connected server needs a restart. It is recorded by updateState on
	// StateConnected and cleared on StateDisabled, so it never has to be
	// synced by hand.
	Config config.MCPConfig

	// PendingConfig is the configuration an in-flight initialization is
	// connecting with. It is set on StateStarting so a config change that
	// arrives mid-connect is compared against the attempt actually in
	// progress rather than the last successful one, which would leave the
	// server skipped as "starting" and never restarted for the new config.
	PendingConfig *config.MCPConfig

	// Channel reports whether this server is an active channel (declared the
	// claude/channel capability and opted in via --channels or
	// channel_enabled in config).
	Channel bool

	// ChannelOptIn reports whether the server is opted in as a channel (via
	// --channels or channel_enabled), whatever its connection state. It is
	// recorded when a connect attempt starts, so a channel that is still
	// starting, has errored, or needs auth is still reported as one.
	ChannelOptIn bool

	// ChannelCapable reports whether the server declared the claude/channel
	// capability on its last connect, whether or not it is opted in, so the
	// UI can point out servers that could be channels but were never enabled.
	ChannelCapable bool
}

// SubscribeEvents returns a channel for MCP events.
//
// Channel message events (EventChannelMessage) are excluded: they carry no
// workspace or session identity, and the MCP broker is process-global. Without
// this filter, every workspace that calls SubscribeEvents would receive every
// other workspace's channel events — a cross-workspace injection path.
// Consumers that deliver channel messages use SubscribeChannelEvents and are
// responsible for scoping each event to the workspaces that declared and
// opted in the originating server.
func SubscribeEvents(ctx context.Context) <-chan pubsub.Event[Event] {
	raw := broker.Subscribe(ctx)
	filtered := make(chan pubsub.Event[Event], 64)
	go func() {
		defer close(filtered)
		for ev := range raw {
			if ev.Payload.Type == EventChannelMessage {
				continue
			}
			select {
			case filtered <- ev:
			case <-ctx.Done():
				return
			}
		}
	}()
	return filtered
}

// SubscribeChannelEvents returns a channel carrying only channel message
// events (EventChannelMessage). The MCP broker is process-global, so these
// events are not scoped to any workspace: every consumer must check that the
// originating server is declared in the target workspace's MCP config and
// opted in (ChannelOptIn) before delivering, otherwise one workspace's
// channel messages leak into another — the injection path SubscribeEvents
// filters out.
func SubscribeChannelEvents(ctx context.Context) <-chan pubsub.Event[Event] {
	raw := broker.Subscribe(ctx)
	channelOnly := make(chan pubsub.Event[Event], 64)
	go func() {
		defer close(channelOnly)
		for ev := range raw {
			if ev.Payload.Type != EventChannelMessage {
				continue
			}
			select {
			case channelOnly <- ev:
			case <-ctx.Done():
				return
			}
		}
	}()
	return channelOnly
}

// GetStates returns the current state of all MCP clients
func GetStates() map[string]ClientInfo {
	return states.Copy()
}

// GetState returns the state of a specific MCP client
func GetState(name string) (ClientInfo, bool) {
	return states.Get(name)
}

// Acquire takes a reference on the process-global MCP clients for an app
// that is about to start them. Pair every Acquire with one Close.
func Acquire() {
	refsMu.Lock()
	defer refsMu.Unlock()
	refs++
}

// Close releases a reference taken by Acquire. Every app in the process
// shares the MCP clients, so only the call that releases the last reference
// closes them. The event broker is never shut down: subscriptions end with
// their contexts, and an app created later in the process still needs it.
//
// A Close that is not the last leaves the releasing app's sessions, OAuth
// handlers and tools in place until another app's Initialize replaces them
// (connectAndRegister closes the session it replaces) or the last app exits.
func Close(ctx context.Context) error {
	refsMu.Lock()
	if refs > 0 {
		refs--
	}
	if refs > 0 {
		refsMu.Unlock()
		return nil
	}
	// Snapshot under the lock so nothing started by an app that acquires
	// after this point is closed here.
	open, handlers := sessions.Copy(), authURLs.Copy()
	refsMu.Unlock()

	var wg sync.WaitGroup
	for name, session := range open {
		wg.Go(func() {
			done := make(chan error, 1)
			go func() {
				done <- session.Close()
			}()
			select {
			case err := <-done:
				if err != nil &&
					!errors.Is(err, io.EOF) &&
					!errors.Is(err, context.Canceled) &&
					err.Error() != "signal: killed" {
					slog.Warn("Failed to shutdown MCP client", "name", name, "error", err)
				}
			case <-ctx.Done():
			}
		})
	}
	wg.Wait()
	// Clean up any remaining OAuth handlers.
	for _, h := range handlers {
		h.Close()
	}
	return nil
}

// Initialize initializes MCP clients based on the provided configuration.
// forceStart lists config-disabled servers with a repository-scoped enabled
// override; they are started even though their config entry is disabled.
// localDisabled lists servers with a repository-scoped disabled override;
// they are not started.
func Initialize(ctx context.Context, permissions permission.Service, cfg *config.ConfigStore, forceStart, localDisabled []string) {
	ArmInit()
	slog.Info("Initializing MCP clients")
	start := time.Now()

	var wg sync.WaitGroup
	// Initialize states for all configured MCPs
	for name, m := range cfg.Config().MCP {
		if slices.Contains(localDisabled, name) {
			updateState(name, StateDisabled, nil, nil, Counts{})
			slog.Debug("Skipping MCP disabled for this repository", "name", name)
			continue
		}
		if m.Disabled {
			if !slices.Contains(forceStart, name) {
				updateState(name, StateDisabled, nil, nil, Counts{})
				slog.Debug("Skipping disabled MCP", "name", name)
				continue
			}
			slog.Info("Starting config-disabled MCP with repository enabled override", "name", name)
		}

		// Set initial starting state
		wg.Add(1)
		goInitClient(ctx, cfg, name, m, &wg)
	}
	wg.Wait()
	initOnce.Do(func() { close(initDone) })
	// Non-interactive runs wait for this to finish before sending a prompt, so
	// the total is the floor on their startup latency. Interactive runs do not
	// wait, but the total still explains when late-arriving tools show up.
	slog.Debug("Finished initializing MCP clients", "duration", time.Since(start).Truncate(time.Millisecond).String())
}

// WaitForInit blocks until MCP initialization is complete, i.e. until
// Initialize has finished and closed initDone. If initialization was never
// armed (ArmInit was not called, e.g. a coordinator built outside app
// startup), there is nothing to wait for and this returns nil immediately
// rather than blocking until ctx is cancelled.
func WaitForInit(ctx context.Context) error {
	initMu.Lock()
	started := initStarted
	initMu.Unlock()
	if !started {
		return nil
	}
	select {
	case <-initDone:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

// InitWaitBudget bounds how long a message turn waits for MCP
// initialization before proceeding without the servers that have not
// finished. It is generously above a healthy stdio server's startup
// (uv/npx take a few seconds) but far below the per-server handshake
// timeouts (15s-120s): a server that wedges mid-handshake — e.g. one
// that never answers the SEP-2575 server/discover probe — must not
// make the whole app look dead while its timeout runs out.
const InitWaitBudget = 10 * time.Second

// WaitForInitBudget blocks like WaitForInit, but only until the budget —
// measured from when initialization was armed, not from this call —
// elapses. Anchoring the deadline at arming means the several sequential
// waiters on a turn's path (readyWg's tool build, then the turn itself)
// share one deadline instead of each stacking a fresh budget while a
// server is wedged, and turns arriving after the deadline don't wait at
// all. It returns nil both when initialization completed and when the
// budget elapsed first — in the latter case the caller proceeds with
// whatever servers have registered so far, and stragglers appear on a
// later turn once they finish. The caller's own context ending is still
// reported as an error.
func WaitForInitBudget(ctx context.Context, budget time.Duration) error {
	initMu.Lock()
	started := initStarted
	armedAt := initArmedAt
	initMu.Unlock()
	if !started {
		return nil
	}
	waitCtx, cancel := context.WithDeadline(ctx, armedAt.Add(budget))
	defer cancel()
	if err := WaitForInit(waitCtx); err == nil {
		return nil
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	slog.Warn("MCP initialization still pending after wait budget; continuing without unfinished servers", "budget", budget)
	return nil
}

// InitializeSingle initializes a single MCP client by name.
func InitializeSingle(ctx context.Context, name string, cfg *config.ConfigStore) error {
	m, exists := cfg.Config().MCP[name]
	if !exists {
		return fmt.Errorf("mcp '%s' not found in configuration", name)
	}

	if m.Disabled {
		updateState(name, StateDisabled, nil, nil, Counts{})
		slog.Debug("Skipping disabled MCP", "name", name)
		return nil
	}

	return initClient(ctx, cfg, name, m, currentGen(name), cfg.Resolver())
}

// InitializeSingleForced starts the named MCP client even when its config
// entry is disabled. Used by the repository-scoped "Toggle MCPs" override.
// The startup counterpart is the forceStart argument of Initialize, which
// replays the persisted enabled overrides. Config files are not touched.
func InitializeSingleForced(ctx context.Context, name string, cfg *config.ConfigStore) error {
	m, exists := cfg.Config().MCP[name]
	if !exists {
		return fmt.Errorf("mcp '%s' not found in configuration", name)
	}

	return initClient(ctx, cfg, name, m, currentGen(name), cfg.Resolver())
}

// AuthenticateMCP initiates the OAuth flow for an MCP server that is in
// StateNeedsAuth. It creates the OAuth handler (which starts a local
// callback server), connects to the server (which triggers the browser
// auth flow on 401), and transitions to StateConnected on success.
func AuthenticateMCP(ctx context.Context, cfg *config.ConfigStore, name string) error {
	m, exists := cfg.Config().MCP[name]
	if !exists {
		return fmt.Errorf("mcp '%s' not found in configuration", name)
	}

	if !m.OAuth || m.Type != config.MCPHttp {
		return fmt.Errorf("mcp '%s' does not use OAuth authentication", name)
	}

	updateState(name, StateStarting, nil, nil, Counts{}, withPending(m), withChannelOptIn(cfg, name, m))

	// This is the user-initiated flow, so permit the interactive browser
	// authorization the handler otherwise withholds during startup.
	ctx = mcpoauth.WithInteractive(ctx)

	// The OAuth handler persists the token automatically as it is
	// exchanged, so a successful connection has already saved it.
	_, err := connectAndRegister(ctx, cfg, name, m, currentGen(name), cfg.Resolver(), ChannelOptIn(m, cfg.Overrides().EnabledChannels, name))
	if err != nil {
		return err
	}
	return nil
}

// PendingAuthServer describes an MCP server awaiting OAuth.
type PendingAuthServer struct {
	Name string
	URL  string
}

// MCPAuthURL returns the current OAuth authorization URL for the named
// MCP, or empty if none is in progress.
func MCPAuthURL(name string) string {
	h, ok := authURLs.Get(name)
	if !ok || h == nil {
		return ""
	}
	return h.AuthURL()
}

// PendingAuthMCPs returns MCP servers in StateNeedsAuth with their URLs.
func PendingAuthMCPs(cfg *config.ConfigStore) []PendingAuthServer {
	var pending []PendingAuthServer
	for name, info := range states.Seq2() {
		if info.State == StateNeedsAuth {
			url := ""
			if m, ok := cfg.Config().MCP[name]; ok {
				url = m.URL
			}
			pending = append(pending, PendingAuthServer{Name: name, URL: url})
		}
	}
	slices.SortFunc(pending, func(a, b PendingAuthServer) int {
		return strings.Compare(a.Name, b.Name)
	})
	return pending
}

// BeginAuth starts the OAuth flow for a server in StateNeedsAuth but
// suppresses opening a local browser; the caller is responsible for
// surfacing the authorization URL (via [MCPAuthURL]) to the user. It returns
// a finish function that must be called exactly once with the request
// context: finish blocks until the flow completes and returns the result.
//
// Only one browser-suppressed flow per server may be in progress. The
// returned cancel function aborts the flow without waiting; use it when the
// caller's context is cancelled.
func BeginAuth(cfg *config.ConfigStore, name string) (finish func(ctx context.Context) error, cancel context.CancelFunc, err error) {
	m, exists := cfg.Config().MCP[name]
	if !exists {
		return nil, nil, fmt.Errorf("mcp '%s' not found in configuration", name)
	}
	if !m.OAuth || m.Type != config.MCPHttp {
		return nil, nil, fmt.Errorf("mcp '%s' does not use OAuth authentication", name)
	}

	lock := suppressLock(name)
	if !lock.TryLock() {
		return nil, nil, fmt.Errorf("mcp '%s' already has an authentication in progress", name)
	}

	flowCtx, flowCancel := context.WithCancel(context.Background())
	flowCtx = mcpoauth.WithInteractive(flowCtx)
	flowCtx = context.WithValue(flowCtx, suppressBrowserKey{}, true)

	finish = func(ctx context.Context) error {
		defer lock.Unlock()
		defer flowCancel()

		done := make(chan error, 1)
		go func() {
			done <- runAuthFlow(flowCtx, cfg, name, m)
		}()

		select {
		case err := <-done:
			return err
		case <-ctx.Done():
			flowCancel()
			<-done
			return ctx.Err()
		}
	}
	return finish, flowCancel, nil
}

// runAuthFlow executes the OAuth connect for BeginAuth with browser
// suppression enabled on the freshly created handler.
func runAuthFlow(ctx context.Context, cfg *config.ConfigStore, name string, m config.MCPConfig) error {
	updateState(name, StateStarting, nil, nil, Counts{}, withPending(m), withChannelOptIn(cfg, name, m))
	_, err := connectAndRegister(ctx, cfg, name, m, currentGen(name), cfg.Resolver(), ChannelOptIn(m, cfg.Overrides().EnabledChannels, name))
	return err
}

// suppressLock returns the per-server mutex used to serialize
// browser-suppressed OAuth flows, creating it on first use.
func suppressLock(name string) *sync.Mutex {
	mu, ok := suppressMus.Get(name)
	if !ok {
		mu = &sync.Mutex{}
		suppressMus.Set(name, mu)
	}
	return mu
}

// initClient initializes a single MCP client with the given configuration.
// gen is the server generation captured when the attempt was launched; the
// resulting session is only committed if the generation is still current, so
// a config change that restarts the server mid-connect discards this attempt.
func initClient(ctx context.Context, cfg *config.ConfigStore, name string, m config.MCPConfig, gen uint64, resolver config.VariableResolver) error {
	// OAuth MCPs without a usable cached token require user interaction
	// (browser auth). If a cached token exists with an access token
	// (even if expired), try connecting first so the SDK can attempt a
	// silent refresh. Only defer to the UI if no token is available at
	// all or the token is structurally invalid (empty access token).
	if m.OAuth && m.Type == config.MCPHttp && !hasUsableToken(m.OAuthToken) {
		if m.OAuthToken != nil {
			clearOAuthToken(cfg, name)
		}
		updateState(name, StateNeedsAuth, nil, nil, Counts{}, withChannelOptIn(cfg, name, m))
		clearMCPData(name)
		slog.Info("MCP server requires OAuth authentication", "name", name)
		return nil
	}

	updateState(name, StateStarting, nil, nil, Counts{}, withPending(m), withChannelOptIn(cfg, name, m))
	_, err := connectAndRegister(ctx, cfg, name, m, gen, resolver, ChannelOptIn(m, cfg.Overrides().EnabledChannels, name))
	if err != nil {
		// If an OAuth MCP fails because the saved token is no longer
		// valid (e.g. refresh token expired or revoked) or no token
		// could be obtained, clear the stale token and prompt the user
		// to re-authenticate instead of leaving the server stuck in
		// StateError.
		if m.OAuth && m.Type == config.MCPHttp && isOAuthInitErr(err) {
			if m.OAuthToken != nil {
				clearOAuthToken(cfg, name)
			}
			updateState(name, StateNeedsAuth, nil, nil, Counts{})
			slog.Info("MCP OAuth token is no longer valid, re-authentication required", "name", name, "error", err)
			return nil
		}
		return err
	}
	return nil
}

// connectAndRegister creates a session, lists tools and prompts,
// registers them in global state, and transitions to StateConnected.
// Returns the session so callers can perform post-processing (e.g.
// token persistence).
//
// gen is the generation captured when this attempt was launched. If the
// server was torn down since (generation bumped), the freshly built session
// is closed and discarded instead of being registered over whatever the
// newer attempt is doing. This is what makes a config change that lands
// mid-connect converge on the latest config rather than a stale one.
func connectAndRegister(ctx context.Context, cfg *config.ConfigStore, name string, m config.MCPConfig, gen uint64, resolver config.VariableResolver, channelOptIn bool) (*ClientSession, error) {
	session, err := createSession(ctx, cfg, name, m, resolver, channelOptIn)
	if err != nil {
		return nil, err
	}

	// A teardown ran while we were connecting: a newer attempt owns this
	// server now. Bail before writing to any shared registry so we don't
	// clobber the newer attempt's registrations; just drop our own session.
	if currentGen(name) != gen {
		slog.Debug("Discarding stale MCP session after config change", "name", name)
		closeSession(name, session)
		return nil, context.Canceled
	}

	toolCount, err := registerSessionTools(ctx, cfg, name, session)
	if err != nil {
		slog.Error("Error listing tools", "error", err)
		updateState(name, StateError, err, nil, Counts{})
		closeSession(name, session)
		return nil, err
	}

	prompts, err := getPrompts(ctx, session)
	if err != nil {
		slog.Error("Error listing prompts", "error", err)
		updateState(name, StateError, err, nil, Counts{})
		closeSession(name, session)
		return nil, err
	}

	// Re-check before publishing: if a teardown landed during registration a
	// newer attempt owns the registries now, so leave them and our session
	// alone rather than overwriting its state.
	if currentGen(name) != gen {
		slog.Debug("Discarding stale MCP session after config change", "name", name)
		closeSession(name, session)
		return nil, context.Canceled
	}

	updatePrompts(name, prompts)
	// Close the session this one replaces. Apps share the sessions and only
	// the last app's Close walks the map, so a session dropped from it here
	// would never be closed. Close it off this path so a slow child cannot
	// hold up Initialize.
	if old, ok := sessions.Swap(name, session); ok && old != session {
		go closeSession(name, old)
	}

	updateState(name, StateConnected, nil, session, Counts{
		Tools:   toolCount,
		Prompts: len(prompts),
	}, withConfig(m))

	return session, nil
}

// persistOAuthToken saves the OAuth token from a session to the global
// config so it survives restarts.

// SetConfigDisabled persists the disabled flag of a single MCP server in
// the given config scope and applies the change to the running client:
// disabling tears the connection down, enabling starts it even if it was
// disabled before. A repository-scoped override takes precedence, so when
// localOverride is set only the config is written.
func SetConfigDisabled(ctx context.Context, cfg *config.ConfigStore, scope config.Scope, name string, disabled, localOverride bool) error {
	if err := cfg.SetMCPServerDisabledConfig(scope, name, disabled); err != nil {
		return err
	}
	if localOverride {
		return nil
	}
	return SetLocalDisabled(ctx, cfg, name, disabled)
}

// SetLocalDisabled applies a repository-scoped toggle to the running
// client: disabling tears the connection down, enabling starts it even if
// its config entry is disabled. Persisting the override is the caller's job.
func SetLocalDisabled(ctx context.Context, cfg *config.ConfigStore, name string, disabled bool) error {
	if disabled {
		return DisableSingle(cfg, name)
	}
	return InitializeSingleForced(ctx, name, cfg)
}

// DisableSingle disables and closes a single MCP client by name.
func DisableSingle(cfg *config.ConfigStore, name string) error {
	// teardown bumps the generation, invalidating any in-flight connect, and
	// the StateDisabled transition clears the recorded config so a later
	// re-enable (even with an unchanged config) is seen as new and restarts.
	teardown(name)
	updateState(name, StateDisabled, nil, nil, Counts{})
	slog.Info("Disabled MCP client", "name", name)
	return nil
}

// goInitClient launches initClient in a goroutine with panic recovery.
// Shared by Initialize and Reinitialize so the panic-to-state policy
// lives in one place. wg, if non-nil, is Done when the attempt finishes
// (success or failure); Initialize uses it to await startup. The goroutine
// captures the server's generation at launch so a concurrent teardown
// invalidates its result rather than letting it register a stale session.
func goInitClient(ctx context.Context, cfg *config.ConfigStore, name string, m config.MCPConfig, wg *sync.WaitGroup) {
	gen := currentGen(name)
	go func() {
		if wg != nil {
			defer wg.Done()
		}
		defer func() {
			if r := recover(); r != nil {
				var err error
				switch v := r.(type) {
				case error:
					err = v
				case string:
					err = fmt.Errorf("panic: %s", v)
				default:
					err = fmt.Errorf("panic: %v", v)
				}
				updateState(name, StateError, err, nil, Counts{})
				slog.Error("Panic in MCP client initialization", "error", err, "name", name)
			}
		}()
		start := time.Now()
		err := initClient(ctx, cfg, name, m, gen, cfg.Resolver())
		slog.Debug(
			"MCP client initialization finished",
			"name", name,
			"duration", time.Since(start).Truncate(time.Millisecond).String(),
			"error", err,
		)
	}()
}

// currentGen returns a server's current generation without bumping it.
func currentGen(name string) uint64 {
	g, _ := gens.Get(name)
	return g
}

// teardown closes a server's session and clears its tools, prompts,
// resources, and auth state, then bumps the server's generation so any
// in-flight initialization for it is discarded on commit. It leaves the
// states entry intact; callers decide whether to delete or update it.
// Shared by DisableSingle, removeServer, and the restart path in
// Reinitialize.
func teardown(name string) {
	g, _ := gens.Get(name)
	gens.Set(name, g+1)
	if session, ok := sessions.Take(name); ok {
		closeSession(name, session)
	}
	clearMCPData(name)
}

func getOrRenewClient(ctx context.Context, cfg *config.ConfigStore, name string) (*ClientSession, error) {
	m := cfg.Config().MCP[name]
	timeout := mcpTimeout(m)

	// Fast path: reuse a healthy session without taking the renewal lock.
	if sess, ok := sessions.Get(name); ok {
		if err := pingSession(ctx, sess, timeout); err == nil {
			return sess, nil
		}
	}

	// Serialize renewals per server. Two concurrent tool calls can both
	// observe a dead session and race to rebuild it: one may close the
	// session the other just registered, or overwrite and leak a live
	// replacement. Under this lock only the first arrival rebuilds; later
	// arrivals re-check and reuse the healthy result.
	mu := renewLock(name)
	mu.Lock()
	defer mu.Unlock()

	// Under the lock the map is stable: any in-flight renewal has finished and
	// either re-registered its session or failed and left none. A renewal
	// removes the session transiently (StateError takes it before rebuilding),
	// so this check must happen here rather than before the lock — otherwise a
	// caller arriving mid-renewal sees no session and wrongly reports the
	// server unavailable.
	sess, ok := sessions.Get(name)
	if !ok {
		return nil, fmt.Errorf("mcp '%s' not available", name)
	}

	// A concurrent goroutine may have already renewed the session while we
	// waited for the lock. Reuse it if it is now healthy.
	pingErr := pingSession(ctx, sess, timeout)
	if pingErr == nil {
		return sess, nil
	}

	state, _ := states.Get(name)
	// StateError closes the dead session and clears its tools, prompts, and
	// resources from the registry. Report the failure against the exact
	// session that failed the ping so only that session is torn down.
	updateState(name, StateError, maybeTimeoutErr(pingErr, timeout), sess, state.Counts)

	// Capture the generation so a reconcile teardown that lands mid-renewal
	// invalidates this rebuild instead of letting it clobber the newer one.
	gen := currentGen(name)
	newSess, err := newSession(ctx, cfg, name, m, cfg.Resolver(), ChannelOptIn(m, cfg.Overrides().EnabledChannels, name))
	if err != nil {
		clearMCPData(name)
		// If an OAuth MCP fails to reconnect because the token is no
		// longer valid, clear the stale token and prompt the user to
		// re-authenticate instead of leaving it in an error state.
		if m.OAuth && m.Type == config.MCPHttp {
			if m.OAuthToken != nil && isOAuthInitErr(err) {
				clearOAuthToken(cfg, name)
			}
			updateState(name, StateNeedsAuth, nil, nil, Counts{})
			slog.Info("MCP OAuth session expired, re-authentication required", "name", name, "error", err)
		}
		return nil, err
	}

	// A reconcile teardown ran while we were rebuilding: a newer attempt owns
	// this server now. Bail before writing to any shared registry so we don't
	// clobber the newer attempt's registrations; just drop our own session.
	if currentGen(name) != gen {
		closeSession(name, newSess)
		return nil, context.Canceled
	}

	// StateError cleared this server's tools, prompts, and resources from the
	// registry. Re-list and re-register them all on the fresh session and
	// recompute the counts from what actually registered; otherwise the agent
	// reconnects but the registries stay empty (the next tool call fails with
	// "tool not found") while the reported counts still advertise capabilities
	// that are no longer there.
	var counts Counts
	counts.Tools, err = registerSessionTools(ctx, cfg, name, newSess)
	if err != nil {
		updateState(name, StateError, err, nil, Counts{})
		closeSession(name, newSess)
		return nil, err
	}

	prompts, err := getPrompts(ctx, newSess)
	if err != nil {
		updateState(name, StateError, err, nil, Counts{})
		closeSession(name, newSess)
		return nil, err
	}
	updatePrompts(name, prompts)
	counts.Prompts = len(prompts)

	resources, err := getResources(ctx, newSess)
	if err != nil {
		updateState(name, StateError, err, nil, Counts{})
		closeSession(name, newSess)
		return nil, err
	}
	counts.Resources = updateResources(name, resources)

	// Re-check before publishing: if a teardown landed during registration a
	// newer attempt owns the registries now, so leave them and our session
	// alone rather than overwriting its state.
	if currentGen(name) != gen {
		closeSession(name, newSess)
		return nil, context.Canceled
	}

	sessions.Set(name, newSess)
	updateState(name, StateConnected, nil, newSess, counts, withConfig(m))
	return newSess, nil
}

// pingSession pings a session with the server's configured timeout.
func pingSession(ctx context.Context, s *ClientSession, timeout time.Duration) error {
	pingCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	err := s.Ping(pingCtx, nil)
	// MethodNotFound means the server answered; it just doesn't implement ping.
	var wireErr *jsonrpc.Error
	if errors.As(err, &wireErr) && wireErr.Code == jsonrpc.CodeMethodNotFound {
		return nil
	}
	return err
}

// closeSession closes an MCP session, logging only unexpected errors. EOF,
// context cancellation, and a killed child are the ordinary result of tearing
// a session down and are not worth surfacing.
func closeSession(name string, s *ClientSession) {
	if err := s.Close(); err != nil &&
		!errors.Is(err, io.EOF) &&
		!errors.Is(err, context.Canceled) &&
		err.Error() != "signal: killed" {
		slog.Warn("Error closing MCP session", "name", name, "error", err)
	}
}

// stateOpt mutates the ClientInfo a transition is about to publish. Config
// recording is opt-in: only the sites that actually own a config (the connect
// and starting paths) pass one, so the many error and count-refresh call sites
// can't accidentally clobber the recorded config by passing a zero value.
type stateOpt func(*ClientInfo)

// withConfig records the config now in effect. Used on StateConnected.
func withConfig(m config.MCPConfig) stateOpt {
	return func(i *ClientInfo) {
		i.Config = m
		i.PendingConfig = nil
	}
}

// withPending records the config an in-flight attempt is connecting with.
// Used on StateStarting.
func withPending(m config.MCPConfig) stateOpt {
	return func(i *ClientInfo) {
		mc := m
		i.PendingConfig = &mc
	}
}

// withChannelOptIn records whether the server is opted in as a channel.
// Applied on every connect attempt so it tracks the current config and the
// --channels overrides.
func withChannelOptIn(cfg *config.ConfigStore, name string, m config.MCPConfig) stateOpt {
	optIn := ChannelOptIn(m, cfg.Overrides().EnabledChannels, name)
	return func(i *ClientInfo) { i.ChannelOptIn = optIn }
}

// updateState updates the state of an MCP client and publishes an event.
//
// Config bookkeeping is split between the caller and the state machine:
//   - Callers that own a config opt in via withConfig (StateConnected) or
//     withPending (StateStarting). Everyone else leaves the recorded config
//     untouched, so an error or count refresh can't wipe it.
//   - The state machine owns the transitions with fixed semantics:
//     StateDisabled clears both so a later re-enable with an unchanged config
//     is seen as new rather than skipped as already initialized.
func updateState(name string, state State, err error, client *ClientSession, counts Counts, opts ...stateOpt) {
	prev, _ := states.Get(name)
	info := prev
	info.Name = name
	info.State = state
	info.Error = err
	info.Client = client
	info.Counts = counts
	info.Channel = client != nil && client.channel
	if client != nil {
		info.ChannelCapable = client.channelCapable
	}
	for _, opt := range opts {
		opt(&info)
	}
	switch state {
	case StateConnected:
		info.ConnectedAt = time.Now()
	case StateDisabled:
		info.Config = config.MCPConfig{}
		info.PendingConfig = nil
		// A disabled server is not a channel, whatever its config says.
		info.ChannelOptIn = false
		info.ChannelCapable = false
	case StateError:
		// A session that has errored is dead to us: close it so the child
		// process and its stdio pipes are released, and clear its registry
		// entries so the agent stops advertising capabilities it can no
		// longer call (without that, crush_info / the `/mcp` menu and the
		// tool list handed to the LLM diverge). Crucially, close exactly the
		// session that errored (the client argument): if the registry
		// already holds a DIFFERENT session — a newer, healthy one another
		// path installed — leave it and its registrations alone. Closing
		// "whatever is in the map" here let a stale error transition (e.g. a
		// refresh that raced a renewal) tear down the healthy replacement.
		switch {
		case client != nil:
			if cur, ok := sessions.Get(name); ok && cur == client {
				sessions.Del(name)
				allTools.Del(name)
				allPrompts.Del(name)
				allResources.Del(name)
			}
			closeSession(name, client)
		default:
			// No specific session errored (e.g. connect itself failed);
			// anything still registered under this name is unusable.
			if old, ok := sessions.Take(name); ok {
				closeSession(name, old)
			}
			allTools.Del(name)
			allPrompts.Del(name)
			allResources.Del(name)
		}
		// Never publish a dead session on the state.
		info.Client = nil
	}
	states.Set(name, info)

	// Publish state change event
	broker.Publish(pubsub.UpdatedEvent, Event{
		Type:   EventStateChanged,
		Name:   name,
		State:  state,
		Error:  err,
		Counts: counts,
	})
}

func createSession(ctx context.Context, cfg *config.ConfigStore, name string, m config.MCPConfig, resolver config.VariableResolver, channelOptIn bool) (*ClientSession, error) {
	timeout := mcpTimeout(m)
	// The session lives until Close, not until ctx ends: callers pass
	// short-lived contexts (an HTTP request in client/server mode, the tool
	// call that renews a dead session), and a stdio server is killed when
	// mcpCtx ends. ctx can still abort the session while it is being set up.
	mcpCtx, cancel := context.WithCancel(context.WithoutCancel(ctx))
	stop := context.AfterFunc(ctx, cancel)
	defer stop()
	cancelTimer := time.AfterFunc(timeout, cancel)

	transport, oauthHandler, err := createTransport(mcpCtx, cfg, name, m, resolver)
	if err != nil {
		updateState(name, StateError, err, nil, Counts{})
		slog.Error("Error creating MCP client", "error", err, "name", name)
		cancel()
		cancelTimer.Stop()
		return nil, err
	}

	// If the caller requested a browser-suppressed flow (server-driven
	// remote auth), suppress the handler's local browser open; the caller
	// surfaces MCPAuthURL(name) to the user on their own machine.
	if oauthHandler != nil {
		if suppress, _ := ctx.Value(suppressBrowserKey{}).(bool); suppress {
			oauthHandler.SetBrowserSuppress(true)
		}
	}

	// Wrap the transport so channel notifications can be intercepted. The
	// gate starts undecided: notifications that arrive during capability
	// negotiation are buffered. After Connect resolves, the gate is opened
	// (and the buffer drained) only when the server declares the channel
	// capability AND was opted in (--channels or channel_enabled);
	// otherwise it is closed (buffer discarded). This prevents early
	// notifications from being lost.
	channelGate := newChannelGate()
	transport = &channelTransport{inner: transport, name: name, gate: channelGate}

	// When the server is marked Sessionless, the tools/prompts/resources
	// list-changed handlers are omitted. The go-sdk opens a SEP-2575
	// "subscriptions/listen" stream whenever any of those handlers is set and
	// the server advertises listChanged (client.go), and sessionless
	// streamable-HTTP servers such as GitHub MCP answer that POST with 404.
	// The SDK tolerates that rejection, so the flag only skips the doomed
	// listen request.
	opts := &mcp.ClientOptions{
		LoggingMessageHandler: func(ctx context.Context, req *mcp.LoggingMessageRequest) {
			level := parseLevel(string(req.Params.Level))
			slog.Log(ctx, level, "MCP log", "name", name, "logger", req.Params.Logger, "data", req.Params.Data)
		},
	}
	if !m.IsSessionless(resolver) {
		opts.ToolListChangedHandler = func(context.Context, *mcp.ToolListChangedRequest) {
			broker.Publish(pubsub.UpdatedEvent, Event{
				Type: EventToolsListChanged,
				Name: name,
			})
		}
		opts.PromptListChangedHandler = func(context.Context, *mcp.PromptListChangedRequest) {
			broker.Publish(pubsub.UpdatedEvent, Event{
				Type: EventPromptsListChanged,
				Name: name,
			})
		}
		opts.ResourceListChangedHandler = func(context.Context, *mcp.ResourceListChangedRequest) {
			broker.Publish(pubsub.UpdatedEvent, Event{
				Type: EventResourcesListChanged,
				Name: name,
			})
		}
	}
	client := mcp.NewClient(
		&mcp.Implementation{
			Name:    "crush",
			Version: version.Version,
			Title:   "Crush",
		},
		opts,
	)

	session, err := client.Connect(mcpCtx, transport, nil)
	if err != nil {
		err = maybeStdioErr(err, transport)
		updateState(name, StateError, maybeTimeoutErr(err, timeout), nil, Counts{})
		slog.Error("MCP client failed to initialize", "error", err, "name", name)
		cancel()
		cancelTimer.Stop()
		return nil, err
	}

	cancelTimer.Stop()
	slog.Debug("MCP client initialized", "name", name)

	// Resolve the channel gate: open only for a server that both declares
	// the claude/channel capability and was opted in — via --channels or
	// channel_enabled in config. Merely listing a server under mcp is not
	// enough. Otherwise close the gate (fail closed). Resolving drains buffered messages
	// that arrived during negotiation so a fast server does not lose early
	// events.
	channelCapable := hasChannelCapability(session.InitializeResult())
	isChannel := channelOptIn && channelCapable
	if isChannel {
		buffered := channelGate.resolve(true)
		for _, raw := range buffered {
			publishChannelMessage(mcpCtx, name, raw)
		}
		slog.Info("MCP channel enabled", "name", name, "buffered", len(buffered))
	} else {
		channelGate.resolve(false)
	}

	return &ClientSession{
		ClientSession:  session,
		cancel:         cancel,
		oauthHandler:   oauthHandler,
		channel:        isChannel,
		channelCapable: channelCapable,
	}, nil
}

// transportWrapper is implemented by every transport decorator crush layers
// around a base transport, so diagnostics that need the innermost transport
// can reach it without knowing which decorators are in play.
type transportWrapper interface {
	unwrapTransport() mcp.Transport
}

// unwrapTransport peels every decorator off a transport and returns the
// innermost one.
func unwrapTransport(transport mcp.Transport) mcp.Transport {
	for {
		w, ok := transport.(transportWrapper)
		if !ok {
			return transport
		}
		transport = w.unwrapTransport()
	}
}

// maybeStdioErr if a stdio mcp prints an error in non-json format, it'll fail
// to parse, and the cli will then close it, causing the EOF error.
// so, if we got an EOF err, and the transport is STDIO, we try to exec it
// again with a timeout and collect the output so we can add details to the
// error.
// this happens particularly when starting things with npx, e.g. if node can't
// be found or some other error like that.
func maybeStdioErr(err error, transport mcp.Transport) error {
	if !errors.Is(err, io.EOF) {
		return err
	}
	// The transport is wrapped in one or more decorators before Connect (the
	// channel gate today); the stdio transport we're probing for is the
	// innermost one. Unwrap all of them — without this the assertion below
	// never matches and stdio startup failures report a bare EOF instead of
	// the child's actual output. Every wrapper must implement
	// unwrapTransport or it will hide this diagnostic again.
	transport = unwrapTransport(transport)
	ct, ok := transport.(*mcp.CommandTransport)
	if !ok {
		return err
	}
	if err2 := stdioCheck(ct.Command); err2 != nil {
		err = errors.Join(err, err2)
	}
	return err
}

func maybeTimeoutErr(err error, timeout time.Duration) error {
	if errors.Is(err, context.Canceled) {
		return fmt.Errorf("timed out after %s", timeout)
	}
	return err
}

func createTransport(ctx context.Context, cfg *config.ConfigStore, name string, m config.MCPConfig, resolver config.VariableResolver) (mcp.Transport, *mcpoauth.Handler, error) {
	switch m.Type {
	case config.MCPStdio:
		command, err := resolver.ResolveValue(m.Command)
		if err != nil {
			return nil, nil, fmt.Errorf("invalid mcp command: %w", err)
		}
		if strings.TrimSpace(command) == "" {
			return nil, nil, fmt.Errorf("mcp stdio config requires a non-empty 'command' field")
		}
		args, err := m.ResolvedArgs(resolver)
		if err != nil {
			return nil, nil, err
		}
		envs, err := m.ResolvedEnv(resolver)
		if err != nil {
			return nil, nil, err
		}
		cmd := exec.CommandContext(ctx, home.Long(command), args...)
		// Start the server in the workspace directory, not the process cwd.
		// In client/server mode one process hosts every workspace and keeps
		// the cwd of whichever client spawned it, so a relative command or
		// argument would otherwise resolve against another project.
		if cfg != nil {
			cmd.Dir = cfg.WorkingDir()
		}
		cmd.Env = append(os.Environ(), envs...)
		// Run the child in its own process group and kill the whole group when
		// the session context is cancelled. A stdio server often spawns its own
		// children (signal-mcp launches signal-cli); os/exec's default
		// cancellation kills only the direct child, orphaning the rest with
		// PPID 1 — production accumulated 15+ such zombies over two days.
		configureStdioProcess(cmd)
		return &mcp.CommandTransport{
			Command: cmd,
		}, nil, nil
	case config.MCPHttp:
		url, err := m.ResolvedURL(resolver)
		if err != nil {
			return nil, nil, err
		}
		if strings.TrimSpace(url) == "" {
			return nil, nil, fmt.Errorf("mcp http config requires a non-empty 'url' field")
		}

		// OAuth-enabled HTTP transport. The handler persists the token
		// (and the client registration/endpoints needed to refresh it)
		// on every exchange and refresh via this saver.
		if m.OAuth {
			tokenSaver := func(tok *oauth.Token) {
				if err := cfg.SetConfigField(config.ScopeGlobal, fmt.Sprintf("mcp.%s.oauth_token", name), tok); err != nil {
					slog.Warn("Failed to persist MCP OAuth token", "name", name, "error", err)
				} else {
					slog.Info("Persisted MCP OAuth token", "name", name)
				}
			}

			// A pre-registered client is required for servers that do not
			// support dynamic client registration (e.g. GitHub, Slack).
			// Resolve the credentials through the shell like other config
			// values so $VAR and $(cmd) work.
			var preregistered *oauth.OAuthClient
			if strings.TrimSpace(m.OAuthClientID) != "" {
				clientID, err := resolver.ResolveValue(m.OAuthClientID)
				if err != nil {
					return nil, nil, fmt.Errorf("oauth_client_id: %w", err)
				}
				clientSecret, err := resolver.ResolveValue(m.OAuthClientSecret)
				if err != nil {
					return nil, nil, fmt.Errorf("oauth_client_secret: %w", err)
				}
				preregistered = &oauth.OAuthClient{
					ClientID:     strings.TrimSpace(clientID),
					ClientSecret: strings.TrimSpace(clientSecret),
				}
			}

			// Normalize trailing slash for PRM discovery compatibility.
			normalizedURL := strings.TrimSuffix(url, "/")
			oauthHandler, oauthErr := mcpoauth.NewHandler(name, normalizedURL, m.OAuthToken, preregistered, tokenSaver, mcpoauth.IsInteractive(ctx), m.OAuthCallbackPort)
			if oauthErr != nil {
				return nil, nil, fmt.Errorf("failed to create OAuth handler for mcp %q: %w", name, oauthErr)
			}
			authURLs.Set(name, oauthHandler)
			return &mcp.StreamableClientTransport{
				Endpoint:     url,
				OAuthHandler: oauthHandler,
			}, oauthHandler, nil
		}

		headers, err := m.ResolvedHeaders(resolver)
		if err != nil {
			return nil, nil, err
		}
		client := &http.Client{
			Transport: &headerRoundTripper{
				headers: headers,
			},
		}
		return &mcp.StreamableClientTransport{
			Endpoint:   url,
			HTTPClient: client,
		}, nil, nil
	case config.MCPSSE:
		url, err := m.ResolvedURL(resolver)
		if err != nil {
			return nil, nil, err
		}
		if strings.TrimSpace(url) == "" {
			return nil, nil, fmt.Errorf("mcp sse config requires a non-empty 'url' field")
		}
		headers, err := m.ResolvedHeaders(resolver)
		if err != nil {
			return nil, nil, err
		}

		var transport http.RoundTripper = &headerRoundTripper{headers: headers}
		var oauthHandler *mcpoauth.Handler

		// SSE transports don't support the SDK's OAuthHandler natively,
		// so we wrap the HTTP transport with our own round-tripper that
		// injects bearer tokens and handles 401-triggered authorization.
		// Based on Bruno Krugel's oauthRoundTripper from PR #3396.
		if m.OAuth {
			tokenSaver := func(tok *oauth.Token) {
				if err := cfg.SetConfigField(config.ScopeGlobal, fmt.Sprintf("mcp.%s.oauth_token", name), tok); err != nil {
					slog.Warn("Failed to persist MCP OAuth token", "name", name, "error", err)
				} else {
					slog.Info("Persisted MCP OAuth token", "name", name)
				}
			}

			var preregistered *oauth.OAuthClient
			if strings.TrimSpace(m.OAuthClientID) != "" {
				clientID, err := resolver.ResolveValue(m.OAuthClientID)
				if err != nil {
					return nil, nil, fmt.Errorf("oauth_client_id: %w", err)
				}
				clientSecret, err := resolver.ResolveValue(m.OAuthClientSecret)
				if err != nil {
					return nil, nil, fmt.Errorf("oauth_client_secret: %w", err)
				}
				preregistered = &oauth.OAuthClient{
					ClientID:     strings.TrimSpace(clientID),
					ClientSecret: strings.TrimSpace(clientSecret),
				}
			}

			// Normalize trailing slash for PRM discovery compatibility.
			normalizedURL := strings.TrimSuffix(url, "/")
			handler, oauthErr := mcpoauth.NewHandler(name, normalizedURL, m.OAuthToken, preregistered, tokenSaver, mcpoauth.IsInteractive(ctx), m.OAuthCallbackPort)
			if oauthErr != nil {
				return nil, nil, fmt.Errorf("failed to create OAuth handler for mcp %q: %w", name, oauthErr)
			}
			oauthHandler = handler
			authURLs.Set(name, handler)
			transport = newOAuthRoundTripper(handler, transport)
		}

		client := &http.Client{Transport: transport}
		return &mcp.SSEClientTransport{
			Endpoint:   url,
			HTTPClient: client,
		}, oauthHandler, nil
	default:
		return nil, nil, fmt.Errorf("unsupported mcp type: %s", m.Type)
	}
}

type headerRoundTripper struct {
	headers map[string]string
}

func (rt headerRoundTripper) RoundTrip(req *http.Request) (*http.Response, error) {
	for k, v := range rt.headers {
		req.Header.Set(k, v)
	}
	return http.DefaultTransport.RoundTrip(req)
}

// oauthRoundTripper wraps an HTTP transport with OAuth bearer token
// injection and 401-triggered authorization. Used for SSE transports
// that don't support the SDK's OAuthHandler natively. Based on Bruno
// Krugel's implementation from PR #3396.
type oauthRoundTripper struct {
	base    http.RoundTripper
	handler auth.OAuthHandler
}

func newOAuthRoundTripper(handler auth.OAuthHandler, base http.RoundTripper) *oauthRoundTripper {
	return &oauthRoundTripper{base: base, handler: handler}
}

func (rt *oauthRoundTripper) RoundTrip(req *http.Request) (*http.Response, error) {
	resp, err := rt.doRequestWithToken(req)
	if err != nil {
		return nil, err
	}

	if resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden {
		if authErr := rt.handler.Authorize(req.Context(), req, resp); authErr != nil {
			return resp, nil
		}
		resp.Body.Close()
		return rt.doRequestWithToken(req.Clone(req.Context()))
	}

	return resp, nil
}

func (rt *oauthRoundTripper) doRequestWithToken(req *http.Request) (*http.Response, error) {
	ts, err := rt.handler.TokenSource(req.Context())
	if err != nil {
		return nil, fmt.Errorf("oauth token source: %w", err)
	}
	if ts != nil {
		token, err := ts.Token()
		if err == nil && token != nil {
			req.Header.Set("Authorization", "Bearer "+token.AccessToken)
		}
	}
	return rt.base.RoundTrip(req)
}

func mcpTimeout(m config.MCPConfig) time.Duration {
	if m.Timeout > 0 {
		return time.Duration(m.Timeout) * time.Second
	}
	// OAuth flows require user interaction in a browser, so use a
	// generous default to avoid timing out mid-auth.
	if m.OAuth {
		return 30 * time.Second
	}
	return 10 * time.Second
}

// hasUsableToken returns true if the saved OAuth token has an access
// token that can be used or refreshed. A token with an empty access
// token is structurally invalid and should be treated as missing.
func hasUsableToken(tok *oauth.Token) bool {
	return tok != nil && tok.AccessToken != ""
}

// isOAuthInitErr returns true if the error indicates the OAuth token
// is missing, no longer valid, or cannot be refreshed. This covers:
//   - invalid_grant: expired or revoked refresh tokens
//   - invalid_client: deleted or deactivated client registrations
//   - "no token available": the handler had no cached token to use
//   - interactive authorization was required but withheld during startup
func isOAuthInitErr(err error) bool {
	if errors.Is(err, mcpoauth.ErrInteractiveAuthRequired) {
		return true
	}
	var rErr *oauth2.RetrieveError
	if errors.As(err, &rErr) {
		return rErr.ErrorCode == "invalid_grant" || rErr.ErrorCode == "invalid_client"
	}
	msg := err.Error()
	return strings.Contains(msg, "invalid_grant") ||
		strings.Contains(msg, "invalid_client") ||
		strings.Contains(msg, "no token available")
}

// clearOAuthToken removes the persisted OAuth token for a named MCP
// server from the global config so subsequent startups don't retry
// with a known-bad refresh token.
func clearOAuthToken(cfg *config.ConfigStore, name string) {
	key := fmt.Sprintf("mcp.%s.oauth_token", name)
	if err := cfg.RemoveConfigField(config.ScopeGlobal, key); err != nil {
		slog.Warn("Failed to clear stale MCP OAuth token", "name", name, "error", err)
	}
}

// clearMCPData removes a stale MCP server's tools, prompts,
// resources, and auth handlers from global state so they are not
// served to the agent.
func clearMCPData(name string) {
	allTools.Del(name)
	allPrompts.Del(name)
	allResources.Del(name)
	if h, ok := authURLs.Get(name); ok {
		h.Close()
		authURLs.Del(name)
	}
}

var stdioCheckTimeout = 5 * time.Second

func stdioCheck(old *exec.Cmd) error {
	ctx, cancel := context.WithTimeout(context.Background(), stdioCheckTimeout)
	defer cancel()
	// old.Args includes argv0 as the first element; exec.CommandContext
	// prepends old.Path as argv0, so we must skip it to avoid duplication
	// (e.g. "npx npx -y pkg" instead of "npx -y pkg").
	args := old.Args
	if len(args) > 0 {
		args = args[1:]
	}
	cmd := exec.CommandContext(ctx, old.Path, args...)
	cmd.Dir = old.Dir
	cmd.Env = old.Env
	cmd.WaitDelay = stdioCheckTimeout
	out, err := cmd.CombinedOutput()
	if err == nil || errors.Is(ctx.Err(), context.DeadlineExceeded) {
		return nil
	}
	return fmt.Errorf("%w: %s", err, string(out))
}
